import tsdownConfig from "../../scripts/tsdownConfig.ts";

export default tsdownConfig;
