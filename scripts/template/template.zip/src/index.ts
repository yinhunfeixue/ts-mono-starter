export function fn() {
  console.log(import.meta.filename);
  return "Hello, index!";
}
